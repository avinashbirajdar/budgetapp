export class config {
  public static ApiUrl: string = "http://localhost:23789/";
}
