export class entyExpenses {
    public ExpenseId: number;
    //public CreditDebitId: number
    public UserCategoryId: number;
    public SubCategoryId: number;
    public DOT: Date;
    public Amount: string;
    public Description: string;
    public PaymentType: string;
    public CategoryName: string;
    public WalletId: number;
    public BankId: number;
    public SubCategoryName: string;
}