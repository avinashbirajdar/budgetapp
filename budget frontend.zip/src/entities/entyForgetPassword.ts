export class entyForgetPassword {
    public Password: string;
    public ConfirmPassword: string;
    public UserId: string;
}