export class entyPerson {
    public PersonId: number;
    public UserId: string;
    public Name: string;
    public Mobile: string;
    public Email: string;
    public Address: string;
    public IsActive: boolean;
}