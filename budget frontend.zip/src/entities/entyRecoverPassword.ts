export class entyRecoverPassword {
    public Email: string;
}