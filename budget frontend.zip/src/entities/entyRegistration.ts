export class entyRegistration {
    public Email: string;
    public UserName: string;
    public Password: string;
    public ConfirmPassword: string;
}