export class entyWallet {
    public WalletId: number;
    public UserId: number;
    public WalletName: string;
    public WalletIcon: string;
    public WalletAmount: string;
    public IconPath: string;
    public IsActive: boolean;
}