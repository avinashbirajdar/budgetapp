export class enty_PaymentMethod {
    public WalletId: number;
    public WalletName: string;
    public BankId: number;
    public BankName: string;
}