// Multicheck 
checkall('inboxAll', 'inbox-chkbox');
checkall('draftAll', 'draft-chkbox');
checkall('sentAll', 'sent-chkbox');
checkall('importantAll', 'important-chkbox');
checkall('trashAll', 'trash-chkbox');