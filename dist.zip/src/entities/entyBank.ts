export class entyBank {
  public BankId: number;
  public UserId: number;
  public BankName: string;
  public BranchName: string;
  public AccountNumber: string;
  public IFSC: string;
  public Amount: string;
}
