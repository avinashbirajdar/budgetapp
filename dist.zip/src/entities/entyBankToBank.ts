export class entyBankToBak {
    public BankTranseferId: number;
    public userId: number;
    public FromBank: number;
    public ToBank: number;
    public Amount: string;
    public Description: string;
}