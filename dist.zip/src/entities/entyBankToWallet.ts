export class entyBankToWallet {
    public BankWalletId: number;
    public BankId: number;
    public WalletId: number;
    public Amount: string;
    public Description: string;
    public BankName: string;
    public WalletName: string;
    public IsActive: boolean;
}