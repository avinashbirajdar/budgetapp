export class entyCategory {
    // public UserCategoryId: number;
    public CategoryId: number;
    public UserId: number;
    public CategoryName: string;
    public CategoryIcon: string;
    public IconPath: string;
}