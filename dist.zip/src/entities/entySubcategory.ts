export class entySubCategory {
    public SubCategoryId: number;
    public CategoryId: number;
    public SubCategoryName: string;
    public CategoryName: string;
    public IconPath: string;
    public IsActive: number;
    public IsUserSubCategory: number;
}