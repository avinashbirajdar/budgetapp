export class entyUserAuthentication {
    public UserName: string;
    public Password: string;
}