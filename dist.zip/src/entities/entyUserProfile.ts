export class entyUserProfile {
	public UserProfileId: number;
	public UserId: string;
	public FirstName: string;
	public LastName: string;
	public Profession: string;
	public DOB: Date;
	public Bio: string;
	public Address: string;
	public Location: string;
	public Phone: string;
	public ProfilePicUrl: string;

}