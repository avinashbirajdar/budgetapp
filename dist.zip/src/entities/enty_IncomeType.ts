export class enty_IncomeType {
    public UserIncomeTypeId: number;
    public UserId: number;
    public IncomeName: string;
    public IsActive: boolean;
}